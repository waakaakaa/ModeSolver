function [ layers ] = generateLayers1D( center, doping, oneCore, nCore )

layers = [];
if ~doping
    layers = [layers;
        [1.2,   3.1694];  %% buffer
        [0.01,  3.2516];  %% grin
        [0.06,  3.2454];  %% grin
        [0.06,  3.2703]];  %% grin
else
    layers = [layers;
        [1.2,   3.1562];  %% buffer
        [0.01,  3.24896];  %% grin
        [0.06,  3.24276];  %% grin
        [0.06,  3.2703]];  %% grin
end

if oneCore
    layers = [layers;
        [0.0875,   nCore]];  %% QW
else
    layers = [layers;
        [0.01,   3.3647];  %% barrier
        [0.0055, 3.5241];  %% well
        [0.01,   3.3647];  %% barrier
        [0.0055, 3.5241];  %% well
        [0.01,   3.3647];  %% barrier
        [0.0055, 3.5241];  %% well
        [0.01,   3.3647];  %% barrier
        [0.0055, 3.5241];  %% well
        [0.01,   3.3647];  %% barrier
        [0.0055, 3.5241];  %% well
        [0.01,   3.3647];  %% barrier
        [0.0055, 3.5241];  %% well
        [0.01,   3.3647];  %% barrier
        [0.0055, 3.5241];  %% well
        [0.01,   3.3647];  %% barrier
        [0.0055, 3.5241];  %% well
        [0.01,   3.3647]];  %% barrier
end

if ~doping
    layers = [layers;
        [0.06,   3.2703];    %% grin
        [0.06,   3.2454];    %% grin
        [0.06,   3.1694];    %% grin
        [0.01,   3.4539]];    %% etch stop
else
    layers = [layers;
        [0.06,   3.2703];    %% grin
        [0.06,   3.24453];    %% grin
        [0.06,   3.16853];    %% grin
        [0.01,   3.45303]];    %% etch stop
end

if center
    if ~doping
        layers = [layers;
            [1.5,    3.1694]];      %% cladding
    else
        layers = [layers;
            [1.5,    3.16724]];      %% cladding
    end
else
    layers = [layers;
        [1.5,    1]];      %% cladding
end


end