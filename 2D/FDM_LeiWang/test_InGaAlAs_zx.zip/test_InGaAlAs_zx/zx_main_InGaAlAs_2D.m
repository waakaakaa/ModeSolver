clc
clear

dx       = 0.05e-6;
dy       = 0.5e-9;
totalwid = 15;
wgwid    = 3;
lambda   = 1.55e-6;

% layers = generateLayers2D_Ridge( 1, 1, 3.4148, totalwid, wgwid);
layers = generateLayers2D_Slab( 1, 1, 3.4156, totalwid, 0);
    
[vThickness, vNeffact, vWidth] = getThickAndNAndWidFromLayers(layers);

[eeps,nx,ny] = getEpsl(vThickness,vNeffact,vWidth,totalwid*1e-6,dx,dy);

A = getFdmMatrix (lambda,dx,dy,eeps,'TE');

[mE,neff_te] = getModes2D(A,max(vNeffact),lambda,nx,ny);

imagesc(linspace(-totalwid,totalwid,nx),[0,sum(vThickness)*1e6],mE);set(gca,'ydir','normal');colorbar;
neff_te

% optical confinement factor
% layerNumbers = round(vThickness/dy);
% Gama = zeros(1,length(layerNumbers));
% for k = 1:length(layerNumbers)-1
%     istart = k;
%     iend   = k+1;
%     nstart = sum(layerNumbers(1:(istart-1))) + 1;
%     nend   = sum(layerNumbers(1:(iend  -1)));
%     Gama(1,k) = sum(sum(abs(mE(nstart:nend,:).^2)))/sum(sum(abs(mE(:,:).^2)));
% end
% sum(Gama(1,5:21))