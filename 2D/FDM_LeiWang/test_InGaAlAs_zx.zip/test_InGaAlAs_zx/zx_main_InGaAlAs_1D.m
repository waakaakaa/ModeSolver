clc
close all
clear all

lambda0 = 1.55e-6;
k0 = 2*pi/lambda0;
dx = 0.05e-9;

layers = generateLayers1D(1,1,1,3.4156);

[vThickness, vNeffAct] = getThickAndNFromLayers(layers);
[eeps] = getEpslFromThickAndN(vThickness,vNeffAct,dx);
[vEte, d] = getMode1D(eeps,k0,dx,max(vNeffAct),lambda0,'TE');
plotyy(sqrt(eeps),'r',abs(vEte.^2),'b');
neff = sqrt(d)/k0