function [ layers ] = generateLayers2D_Ridge( doping, oneCore, nCore, totalwid, wgwid)

layers = [];
if ~doping
    layers = [layers;
        [1.2,   3.1694,  totalwid];  %% buffer
        [0.01,  3.2516,  totalwid];  %% grin
        [0.06,  3.2454,  totalwid];  %% grin
        [0.06,  3.2703,  totalwid]];  %% grin
else
    layers = [layers;
        [1.2,   3.1562,   totalwid];  %% buffer
        [0.01,  3.24896,  totalwid];  %% grin
        [0.06,  3.24276,  totalwid];  %% grin
        [0.06,  3.2703],  totalwid];  %% grin
end

if oneCore
    layers = [layers;
        [0.0875,   nCore,  totalwid]];  %% QW
else
    layers = [layers;
        [0.01,   3.3647,  totalwid];  %% barrier
        [0.0055, 3.5241,  totalwid];  %% well
        [0.01,   3.3647,  totalwid];  %% barrier
        [0.0055, 3.5241,  totalwid];  %% well
        [0.01,   3.3647,  totalwid];  %% barrier
        [0.0055, 3.5241,  totalwid];  %% well
        [0.01,   3.3647,  totalwid];  %% barrier
        [0.0055, 3.5241,  totalwid];  %% well
        [0.01,   3.3647,  totalwid];  %% barrier
        [0.0055, 3.5241,  totalwid];  %% well
        [0.01,   3.3647,  totalwid];  %% barrier
        [0.0055, 3.5241,  totalwid];  %% well
        [0.01,   3.3647,  totalwid];  %% barrier
        [0.0055, 3.5241,  totalwid];  %% well
        [0.01,   3.3647,  totalwid];  %% barrier
        [0.0055, 3.5241,  totalwid];  %% well
        [0.01,   3.3647,  totalwid]];  %% barrier
end

if ~doping
    layers = [layers;
        [0.06,   3.2703,  totalwid];    %% grin
        [0.06,   3.2454,  totalwid];    %% grin
        [0.06,   3.1694,  totalwid];    %% grin
        [0.01,   3.4539,  totalwid]];    %% etch stop
else
    layers = [layers;
        [0.06,   3.2703,  totalwid];    %% grin
        [0.06,   3.24453,  totalwid];    %% grin
        [0.06,   3.16853,  totalwid];    %% grin
        [0.01,   3.45303,  totalwid]];    %% etch stop
end


if ~doping
    layers = [layers;
        [1.5,    3.1694,   wgwid]];      %% cladding
else
    layers = [layers;
        [1.5,    3.16724,  wgwid]];      %% cladding
end



end